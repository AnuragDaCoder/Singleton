using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Single_Instance_Is_Not_Null()
        {
            var result = Singleton.Instance;
            Assert.IsNotNull(result);
        }


        [TestMethod]
        public void Only_One_Instance_Of_Singleton()
        {
            var result1 = Singleton.Instance;
            var result2 = Singleton.Instance;
            var result3 = Singleton.Instance;
            Assert.AreEqual(1, Singleton.constructorInvokedCount);
            Assert.AreEqual(3, Singleton.instanceInvoked);
        }

        [TestMethod]
        public void More_Than_One_Instance_Of_Singleton_In_MultiThreading()
        {
            var instances = new List<Singleton>();
            var options = new ParallelOptions { MaxDegreeOfParallelism = 3 };
            var strings = new List<int>() { 1, 2, 3 };
            Parallel.ForEach(strings, options, instance =>
             {
                 instances.Add(Singleton.Instance);
             });
            System.Console.WriteLine(Singleton.constructorInvokedCount);
            Assert.IsTrue(Singleton.constructorInvokedCount == 1);//3
            Assert.AreEqual(3, Singleton.instanceInvoked);
        }

        [TestMethod]
        public void Singleton_with_static_and_private_constructor()
        {
            //private constructor --> static constructor --> then get 
            var result1 = Singleton.Instance;
            var result2 = Singleton.Instance;
            var result3 = Singleton.Instance;
            Assert.AreEqual(1, Singleton.constructorInvokedCount);
            Assert.AreEqual(3, Singleton.instanceInvoked);
        }

        [TestMethod]
        public void Singleton_with_only_private_constructor()
        {
            //get --> private constructor
            var result1 = Singleton.Instance;
            var result2 = Singleton.Instance;
            var result3 = Singleton.Instance;
            Assert.AreEqual(1, Singleton.constructorInvokedCount);
            Assert.AreEqual(3, Singleton.instanceInvoked);
        }


        [TestMethod]
        public void Singleton_with_only_private_and_no_static_constructor_static_method_invoked()
        {
            //say hello
            //Singleton.hello();
            //instance gets created in next line which is fine
            var result1 = Singleton.Instance;
            var result2 = Singleton.Instance;
            var result3 = Singleton.Instance;
            Assert.AreEqual(1, Singleton.constructorInvokedCount);
            Assert.AreEqual(3, Singleton.instanceInvoked);
        }

        [TestMethod]
        public void Singleton_with_only_private_and_static_constructor_static_method_invoked()
        {
            //private constructor --> static constructor --> then get --> say hello
            //Singleton.hello(); 
            // you may not want to instantiate at this point of time if 
            //I am invoking a static method 
            //I want my singleton to be fully lazy
            var result1 = Singleton.Instance;
            var result2 = Singleton.Instance;
            var result3 = Singleton.Instance;
            Assert.AreEqual(1, Singleton.constructorInvokedCount);
            Assert.AreEqual(3, Singleton.instanceInvoked);
        }
    }
}