﻿//#nullable enable
//public sealed class Singleton
//{
//    public static int constructorInvokedCount = 0;
//    public static int instanceInvoked = 0;
//    private static Singleton? _instance;

//    public static Singleton Instance
//    {
//        get
//        {
//            instanceInvoked++;
//            return _instance ?? (_instance = new Singleton());
//        }
//    }

//    private Singleton()
//    {
//        constructorInvokedCount++;
//        Console.Write("Constructor invoked");
//    }
//    public static void Main(string[] args)
//    {

//    }
//}

#nullable enable
public sealed class Singleton
{
    public static int constructorInvokedCount = 0;
    public static int instanceInvoked = 0;
    private static Singleton? _instance;
    private static readonly object padlock = new object();

    public static Singleton Instance
    {
        get
        {
            instanceInvoked++;

            lock (padlock)
            {
                if (_instance == null)
                {
                    _instance = new Singleton();
                }
                return _instance;
            }

        }
    }

    //static Singleton()
    //{
    //    Console.Write("static constructor invoked");
    //}

    private Singleton()
    {
        constructorInvokedCount++;
        Console.Write("Constructor invoked");
    }
    public static void Main(string[] args)
    {

    }
}

//#nullable enable
//public sealed class Singleton
//{
//    public static int constructorInvokedCount = 0;
//    public static int instanceInvoked = 0;


//    private static readonly Lazy<Singleton> lazyInstance = new Lazy<Singleton>(() => new Singleton());

//    public static Singleton Instance { 
//        get {
//            instanceInvoked++;
//            return lazyInstance.Value; 
//        } 
//    }

//    public static string hello()
//    {
//        return "hello";
//    }

//    private Singleton()
//    {
//        constructorInvokedCount++;
//        Console.Write("Constructor invoked");
//    }
//    public static void Main(string[] args)
//    {

//    }
//}



